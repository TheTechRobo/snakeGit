from setuptools import setup

setup(
    name='pyGit',
    version='v.0.2.1-stable',
    description='the missing Python git module',
    license='DBAD',
    packages=['pygit'],
    author='ittussarom retals mail ynohtna',
    author_email='thetechrobo@outlook.com',
    keywords=['git', 'easy', 'thetechrobo'],
    url='https://github.com/TheTechRobo/PyGit'
)
