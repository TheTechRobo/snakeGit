# pyGit
A small module for running Git operations...

**Check out [Palc](https://github.com/thetechrobo/python-text-calculator), it's even better than pyGit**

**NOTE: pyGit has not finished development yet. Use with caution!**

![pyGit in use](https://thetechrobo.github.io/resources-online/OK%20BOOMERv3.gif)

**NOTE 2: pyGit is STILL BEING MAINTAINED. It's just not my priority, as I've been pretty busy lately.**

Documentation and details are in the [wiki](https://github.com/thetechrobo/pygit/wiki).

# Installing from PyPI
pyGit is on PyPI with the name `pyyGit` (due to another project with the name pyGit). However, you still need to use `import pyGit` or `from pyGit import *` instead of `import pyygit` or `from pyygit import *`. Because the *package name* is pyGit but the PyPI name is pyyGit.
